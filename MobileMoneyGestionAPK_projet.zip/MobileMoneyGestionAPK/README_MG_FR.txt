MOBILE MONEY GESTION — PROJET ANDROID

Ity ZIP ity dia PROJET/source Android, fa tsy APK efa vita.
Application offline: MVola, Orange Money, Airtel Money, opérations, dépenses, historique, tarifs, notes/dettes et sauvegarde.
Tsy mifandray amin'ny opérateurs ary tsy manao transfert Mobile Money.

Fomba hanamboarana APK:
1. Mila ordinateur (Windows/Mac/Linux) misy Android Studio.
2. Décompresser ity ZIP ity.
3. Sokafy Android Studio > Open > fidio ny dossier MobileMoneyGestionAPK.
4. Avelao hisintona Gradle/Android SDK raha mangataka izy.
5. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Rehefa vita, tsindrio Locate; ny APK debug dia matetika ao amin'ny app/build/outputs/apk/debug/app-debug.apk.
7. Alefaso amin'ny finday Android ilay APK ary sokafy mba hametrahana azy. Mety hangataka alalana hametraka application avy amin'io source io ny Android.

ZAVA-DEHIBE:
- Ny angona dia voatahiry eo amin'io application io amin'io finday io. Tsy misy synchronisation cloud.
- Ny fametrahana application vaovao dia mety tsy hitondra ho azy ny angona tao amin'ilay fichier HTML taloha. Ataovy export/sauvegarde aloha.
- Tsy tokony hampiditra PIN, mot de passe, code OTP, na kaody miafina an'ny Mobile Money ao amin'ny app.
- Ny application dia fitaovana fitanana an-tsoratra sy kajy tombana ihany.

English/French technical note: Android Studio project using a local HTML asset in a WebView. Minimum Android 6.0 (API 23).
